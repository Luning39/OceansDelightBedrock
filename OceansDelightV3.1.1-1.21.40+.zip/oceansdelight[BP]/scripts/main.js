import { LootingRegister } from "./register/LootingRegister";
import { FoodRegister } from "./register/FoodRegister";
new LootingRegister();
new FoodRegister();
//# sourceMappingURL=main.js.map